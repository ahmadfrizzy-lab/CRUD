<?php
require_once "config/database.php";

// Query Produk Terbaru
$query_produk = mysqli_query($conn, "SELECT * FROM produk ORDER BY id DESC LIMIT 6");
$is_admin = isset($_SESSION['admin_logged_in']) && $_SESSION['admin_logged_in'] === true;
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sweet Cake - Toko Kue</title>
    <!-- Bootstrap 5 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">

<!-- Navbar Utama -->
<nav class="navbar navbar-expand-lg navbar-dark bg-dark sticky-top">
  <div class="container">
    <a class="navbar-brand fw-bold text-warning" href="index.php">Sweet Cake</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
      <span class="navbar-toggler-icon"></span>
    </button>

    <div class="collapse navbar-collapse" id="navbarNav">
      <ul class="navbar-nav me-auto">
        <li class="nav-item"><a class="nav-link active" href="index.php">Beranda</a></li>
        <li class="nav-item"><a class="nav-link" href="produk.php">Produk</a></li>
        <li class="nav-item"><a class="nav-link" href="tentang.php">Tentang Kami</a></li>
      </ul>

      <!-- Area Login / Status Admin -->
      <div class="d-flex align-items-center">
        <?php if ($is_admin): ?>
            <span class="text-light me-3">Halo, <strong><?= htmlspecialchars($_SESSION['admin_nama']); ?></strong> (Admin)</span>
            <a href="admin/produk.php" class="btn btn-warning btn-sm fw-bold me-2">Kelola Produk (CRUD)</a>
            <a href="proses_auth.php?aksi=logout" class="btn btn-outline-danger btn-sm" onclick="return confirm('Logout dari akun Admin?')">Logout</a>
        <?php else: ?>
            <button class="btn btn-outline-warning btn-sm fw-bold" data-bs-toggle="modal" data-bs-target="#modalLoginAdmin">
                🔐 Login Admin
            </button>
        <?php endif; ?>
      </div>
    </div>
  </div>
</nav>

<!-- Alert Pesan Notifikasi -->
<div class="container mt-3">
    <?php if (isset($_SESSION['error_msg'])): ?>
        <div class="alert alert-danger alert-dismissible fade show" role="alert">
            <?= $_SESSION['error_msg']; unset($_SESSION['error_msg']); ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    <?php if (isset($_SESSION['success_msg'])): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <?= $_SESSION['success_msg']; unset($_SESSION['success_msg']); ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>
</div>

<!-- Hero Banner -->
<section class="bg-warning text-dark py-5 text-center mb-4">
    <div class="container">
        <h1 class="fw-bold">Sweet Cake</h1>
        <p class="lead">Kue lezat untuk setiap momen spesial Anda.</p>
        <a href="produk.php" class="btn btn-dark btn-lg fw-bold">Lihat Semua Produk</a>
    </div>
</section>

<!-- Konten Utama: Produk Terbaru -->
<div class="container my-4">
    <h3 class="fw-bold mb-4">Produk Terbaru</h3>
    <div class="row g-4">
        <?php while ($row = mysqli_fetch_assoc($query_produk)): ?>
        <div class="col-md-4">
            <div class="card h-100 shadow-sm border-0">
                <?php if ($row['gambar']): ?>
                    <img src="uploads/produk/<?= htmlspecialchars($row['gambar']); ?>" class="card-img-top" style="height: 220px; object-fit: cover;">
                <?php endif; ?>
                <div class="card-body">
                    <span class="badge bg-info text-dark mb-2"><?= htmlspecialchars($row['kategori']); ?></span>
                    <h5 class="card-title fw-bold"><?= htmlspecialchars($row['nama']); ?></h5>
                    <p class="card-text text-muted small"><?= htmlspecialchars(substr($row['deskripsi'], 0, 80)); ?>...</p>
                    <h6 class="text-success fw-bold">Rp <?= number_format($row['harga'], 0, ',', '.'); ?></h6>
                </div>
                <div class="card-footer bg-white border-0 pb-3">
                    <a href="detail.php?id=<?= $row['id']; ?>" class="btn btn-primary w-100 fw-bold">Lihat Detail</a>
                </div>
            </div>
        </div>
        <?php endwhile; ?>
    </div>
</div>

<!-- Modal Popup Login Admin -->
<div class="modal fade" id="modalLoginAdmin" tabindex="-1" aria-labelledby="modalLoginAdminLabel" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered" style="max-width: 400px;">
    <div class="modal-content">
      <div class="modal-header bg-dark text-white">
        <h5 class="modal-title fw-bold text-warning" id="modalLoginAdminLabel">Login Admin</h5>
        <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <form action="proses_auth.php" method="POST">
          <div class="modal-body">
              <div class="mb-3">
                  <label class="form-label font-weight-bold">Username</label>
                  <input type="text" name="username" class="form-control" placeholder="Masukkan username" required>
              </div>
              <div class="mb-3">
                  <label class="form-label font-weight-bold">Password</label>
                  <input type="password" name="password" class="form-control" placeholder="Masukkan password" required>
              </div>
          </div>
          <div class="modal-footer">
              <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
              <button type="submit" name="login_admin" class="btn btn-warning fw-bold">Login</button>
          </div>
      </form>
    </div>
  </div>
</div>

<!-- Bootstrap 5 JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>