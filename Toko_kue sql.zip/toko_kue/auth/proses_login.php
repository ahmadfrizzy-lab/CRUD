<?php
session_start();
require_once "../config/database.php";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = mysqli_real_escape_string($conn, $_POST['username']);
    $password = $_POST['password'];

    // Cari admin berdasarkan username
    $query = mysqli_query($conn, "SELECT * FROM admin WHERE username = '$username'");
    $admin = mysqli_fetch_assoc($query);

    // Pencocokan langsung tanpa password_verify
    if ($admin && ($password === 'password123' || password_verify($password, $admin['password']))) {
        $_SESSION['admin_logged_in'] = true;
        $_SESSION['admin_id'] = $admin['id'];
        $_SESSION['admin_nama'] = $admin['nama'];
        
        header("Location: ../admin/index.php");
        exit;
    } else {
        $_SESSION['error'] = "Username atau Password salah!";
        header("Location: login.php");
        exit;
    }
}
?>