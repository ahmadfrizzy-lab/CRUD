<?php
require_once "../includes/auth.php";
check_login();
require_once "../config/database.php";
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Kelola Produk - Admin</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
<nav class="navbar navbar-expand-lg navbar-dark bg-dark mb-4">
  <div class="container">
    <a class="navbar-brand fw-bold text-warning" href="index.php">Sweet Cake Admin</a>
    <div class="navbar-nav ms-auto">
      <a class="nav-link" href="index.php">Dashboard</a>
      <a class="nav-link active" href="produk.php">Kelola Produk</a>
      <a class="nav-link text-danger fw-bold" href="logout.php">Logout</a>
    </div>
  </div>
</nav>

<div class="container">
    <div class="card shadow border-0 p-4">
        <div class="d-flex justify-content-between align-items-center mb-3">
            <h4 class="fw-bold m-0 text-primary">Daftar Produk</h4>
            <a href="tambah.php" class="btn btn-success fw-bold">+ Tambah Produk</a>
        </div>

        <div class="table-responsive">
            <table class="table table-hover align-middle table-bordered">
                <thead class="table-dark">
                    <tr>
                        <th width="50" class="text-center">No</th>
                        <th width="100" class="text-center">Gambar</th>
                        <th>Nama</th>
                        <th>Kategori</th>
                        <th>Harga</th>
                        <th>Stok</th>
                        <th width="160" class="text-center">Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $no = 1;
                    $query = mysqli_query($conn, "SELECT * FROM produk ORDER BY id DESC");
                    while ($row = mysqli_fetch_assoc($query)) :
                    ?>
                    <tr>
                        <td class="text-center"><?= $no++; ?></td>
                        <td class="text-center">
                            <?php if ($row['gambar']): ?>
                                <img src="../uploads/produk/<?= htmlspecialchars($row['gambar']); ?>" class="img-thumbnail" style="height:55px; object-fit:cover;">
                            <?php else: ?>
                                <span class="text-muted small">No Img</span>
                            <?php endif; ?>
                        </td>
                        <td class="fw-bold"><?= htmlspecialchars($row['nama']); ?></td>
                        <td><span class="badge bg-info text-dark"><?= htmlspecialchars($row['kategori']); ?></span></td>
                        <td class="text-success fw-bold">Rp <?= number_format($row['harga'], 0, ',', '.'); ?></td>
                        <td><span class="badge bg-secondary"><?= $row['stok']; ?> pcs</span></td>
                        <td class="text-center">
                            <a href="edit.php?id=<?= $row['id']; ?>" class="btn btn-sm btn-primary">Edit</a>
                            <a href="hapus.php?id=<?= $row['id']; ?>" class="btn btn-sm btn-danger" onclick="return confirm('Hapus produk ini?')">Hapus</a>
                        </td>
                    </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
</body>
</html>