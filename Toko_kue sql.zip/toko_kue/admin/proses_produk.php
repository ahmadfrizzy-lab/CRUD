<?php
require_once "../includes/auth.php";
check_login();
require_once "../config/database.php";

if (isset($_POST['aksi'])) {
    $aksi      = $_POST['aksi'];
    $nama      = mysqli_real_escape_string($conn, $_POST['nama']);
    $kategori  = mysqli_real_escape_string($conn, $_POST['kategori']);
    $harga     = (float)$_POST['harga'];
    $stok      = (int)$_POST['stok'];
    $deskripsi = mysqli_real_escape_string($conn, $_POST['deskripsi']);

    $nama_gambar = NULL;
    if (isset($_FILES['gambar']) && $_FILES['gambar']['error'] === UPLOAD_ERR_OK) {
        $ext = pathinfo($_FILES['gambar']['name'], PATHINFO_EXTENSION);
        $nama_gambar = time() . '_' . uniqid() . '.' . $ext;
        $target = "../uploads/produk/" . $nama_gambar;

        if (!is_dir("../uploads/produk/")) {
            mkdir("../uploads/produk/", 0777, true);
        }
        move_uploaded_file($_FILES['gambar']['tmp_name'], $target);
    }

    if ($aksi === "tambah") {
        $sql = "INSERT INTO produk (nama, kategori, harga, stok, deskripsi, gambar) 
                VALUES ('$nama', '$kategori', '$harga', '$stok', '$deskripsi', " . ($nama_gambar ? "'$nama_gambar'" : "NULL") . ")";
        mysqli_query($conn, $sql);
    } elseif ($aksi === "edit") {
        $id = (int)$_POST['id'];
        $gambar_lama = $_POST['gambar_lama'];

        if ($nama_gambar) {
            if ($gambar_lama && file_exists("../uploads/produk/" . $gambar_lama)) {
                unlink("../uploads/produk/" . $gambar_lama);
            }
            $gambar_final = $nama_gambar;
        } else {
            $gambar_final = $gambar_lama;
        }

        $sql = "UPDATE produk SET 
                nama='$nama', kategori='$kategori', harga='$harga', stok='$stok', deskripsi='$deskripsi',
                gambar=" . ($gambar_final ? "'$gambar_final'" : "NULL") . " 
                WHERE id=$id";
        mysqli_query($conn, $sql);
    }
}
header("Location: produk.php");
exit;
?>