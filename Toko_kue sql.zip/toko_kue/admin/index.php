<?php
require_once "../includes/auth.php";
check_login();
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Dashboard Admin</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
<nav class="navbar navbar-expand-lg navbar-dark bg-dark mb-4">
  <div class="container">
    <a class="navbar-brand fw-bold text-warning" href="index.php">Sweet Cake Admin</a>
    <div class="navbar-nav ms-auto">
      <a class="nav-link active" href="index.php">Dashboard</a>
      <a class="nav-link" href="produk.php">Kelola Produk</a>
      <a class="nav-link text-danger fw-bold" href="logout.php">Logout</a>
    </div>
  </div>
</nav>
<div class="container">
    <div class="card shadow-sm p-4">
        <h3>Halo, <?= htmlspecialchars($_SESSION['admin_nama']); ?>! 👋</h3>
        <p class="text-muted">Selamat datang di Panel Kontrol Admin Sweet Cake.</p>
        <div>
            <a href="produk.php" class="btn btn-primary fw-bold">Kelola Produk Sekarang</a>
        </div>
    </div>
</div>
</body>
</html>