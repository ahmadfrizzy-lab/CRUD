<?php
require_once "../includes/auth.php";
check_login();
require_once "../config/database.php";

$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

if ($id > 0) {
    $query = mysqli_query($conn, "SELECT gambar FROM produk WHERE id = $id");
    $data = mysqli_fetch_assoc($query);

    if ($data && $data['gambar']) {
        $file = "../uploads/produk/" . $data['gambar'];
        if (file_exists($file)) {
            unlink($file);
        }
    }
    mysqli_query($conn, "DELETE FROM produk WHERE id = $id");
}
header("Location: produk.php");
exit;
?>