<?php
require_once "config/database.php";

$aksi = $_GET['aksi'] ?? '';

// LOGOUT
if ($aksi === 'logout') {
    session_destroy();
    header("Location: index.php");
    exit;
}

// LOGIN
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['login_admin'])) {
    $username = mysqli_real_escape_string($conn, $_POST['username']);
    $password = $_POST['password'];

    $query = mysqli_query($conn, "SELECT * FROM admin WHERE username = '$username'");
    $admin = mysqli_fetch_assoc($query);

    if ($admin && ($password === 'password123' || password_verify($password, $admin['password']))) {
        $_SESSION['admin_logged_in'] = true;
        $_SESSION['admin_id']        = $admin['id'];
        $_SESSION['admin_nama']      = $admin['nama'];
        $_SESSION['success_msg']     = "Berhasil login sebagai Admin!";
    } else {
        $_SESSION['error_msg']       = "Username atau Password salah!";
    }

    header("Location: index.php");
    exit;
}
?>